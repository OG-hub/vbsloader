#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("BonJour\n");

    while(1);
    return 0;
}
